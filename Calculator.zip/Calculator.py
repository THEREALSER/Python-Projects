import logo
def sum(n1,n2):
    return n1 + n2
def sub(n1,n2):
    return n1 - n2
def divide(n1,n2):
    return n1 / n2
def multiply(n1,n2):
    return n1 * n2

operations = {"+" : sum, "-" : sub, "/" : divide, "*" : multiply}



def calculator():
    print(logo.logo)
    num1 = float(input("First number: "))
    should_accumulate = True
    while should_accumulate:
        for symbol in operations:
            print(symbol)
        operations_symbol = input("Pick an operation: ")
        num2 = float(input("Last number: "))
        answer = operations[operations_symbol](num1, num2)
        print(f"{num1} {operations_symbol} {num2} = {answer}")
        choice = input(f"Type 'y' to continue calculating with {answer} or type 'n' to start a new calculation: ")
        if choice == "y":
            num1 = answer
        else:
            should_accumulate = False
            print(20 * "\n")
            calculator()

calculator()