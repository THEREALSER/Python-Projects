word_list = ["aardvark", "baleia", "camelo", "doninha", "elefante",
             "flamingo", "galinha", "hiena", "iguana", "jararaca",
             "kiwi", "lince", "morsa", "narval", "ovelha", "papagaio",
             "quati", "rinoceronte", "suricate", "tartaruga", "urso",
             "vagalume", "wallaby", "ximango", "yak", "zebra"]